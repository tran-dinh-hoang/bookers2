# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '0f50d7d0572c533bbcc77c45850608fe33ba68c420eccce13af5c69692b201217aa9023c7f8c305eca764f16a819b7015267caf1ce45e1280b5e9321b4b9dec9'
